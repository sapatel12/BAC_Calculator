package hk.ust.cse.comp107x.alc;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;



public class MainActivity extends AppCompatActivity {

    EditText liquid;
    EditText weight;
    EditText gender;
    EditText hours;
    EditText percent;
    EditText fin;
    Button stopGo;
    TextView waitTime;
    Button more;

    int oz = 0;
    int lbs = 0;
    double gen = 0;
    double hrs = 0;
    double per = 0;
    double bac = 0;
    double wait = 0;
    double ave = 0;

    ArrayList<Double> bacs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Code for Fluid oz of alcohol
        liquid = (EditText) findViewById(R.id.liquidLabel);
        showKeyboard();
        liquid.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String val = liquid.getText().toString();
                try {
                    oz = Integer.parseInt(val);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                setFinal();
            }
        });



        // Code for weight of person
        weight = (EditText) findViewById(R.id.weightLabel);
        weight.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String val = weight.getText().toString();
                    try {
                        lbs = Integer.parseInt(val);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                setFinal();
            }
        });



        // Code for gender of person
        gender = (EditText) findViewById(R.id.genderLabel);
        gender.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String val = gender.getText().toString();
                    if (val == "F" || val == "f" || val == "female" || val == "Female") {
                        gen = 0.66;
                    } else {
                        gen = 0.73;
                    }
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                setFinal();
            }
        });


        // Code for hours elapsed
        hours = (EditText) findViewById(R.id.hoursLabel);
        hours.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String val = hours.getText().toString();
                try {
                    hrs = Double.parseDouble(val);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                setFinal();
            }
        });


        // Code for percent of alcohol
        percent = (EditText) findViewById(R.id.percentLabel);
        percent.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String val = percent.getText().toString();
                try {
                    per = Double.parseDouble(val) / 100.0;
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                setFinal();


                percent.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if (!hasFocus) {
                            hideKeyboard(v);
                        }
                    }
                });
            }
        });

        more = (Button) findViewById(R.id.addMoreButton);
        more.setOnClickListener(event1);


        stopGo = (Button) findViewById(R.id.stopGoButton);
        stopGo.setOnClickListener(event2);
    }










    // Clicking add more button
    View.OnClickListener event1 = new View.OnClickListener() {
        public void onClick(View v) {
            bacs.add(bac);
            reset();
        }
    };



    // Clicking wait time button
    View.OnClickListener event2 = new View.OnClickListener() {
        public void onClick(View v) {
            waitTime = (TextView) findViewById(R.id.timeToWaitText);
            try {
                if (ave >= 0) {
                    wait = (ave - 0.05) / 0.015;
                    String value = new BigDecimal(wait).setScale(1, RoundingMode.DOWN).stripTrailingZeros().toString();
                    if (wait >= 0 && wait < 24) {
                        waitTime.setText("You must wait " + value + " hours before driving again.");
                        waitTime.setTypeface(null, Typeface.BOLD);
                    }
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    public void setFinal() {
        fin = (EditText) findViewById(R.id.bacLabel);
        fin.setEnabled(false);
        stopGo = (Button) findViewById(R.id.stopGoButton);
        try {
            bac = ((((oz * per) * 5.14) / (lbs * gen)) - (0.015 * hrs));
                if (bac > 0) {
                    ave = bacAverage(bac);
                    if (!(ave >= 0)) {
                        ave = bac;
                    }
                    String value = Double.toString(ave);
                    fin.setText(value);
                    fin.setTypeface(null, Typeface.BOLD);
                    if (ave > 0.08) {
                        stopGo.setText("Your BAC is over the legal limit! Click me!");
                    } else {
                        stopGo.setText("You're clear to drive. Stay safe!");
                    }
                }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void showKeyboard() {
        liquid.postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager keyboard = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                keyboard.showSoftInput(liquid, 0);
            }
        },50);
    }

    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager =(InputMethodManager)getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }








    public double bacAverage(double current) {
        double sum = current;
        int n = bacs.size();
        for (int i = 0; i < n; i++) {
            sum += bacs.get(i);
        }
        n++;
        return sum/n;
    }

    public void reset() {
        oz = 0;
        lbs = 0;
        gen = 0;
        hrs = 0;
        per = 0;
        bac = 0;
        wait = 0;

        liquid.setText("");
        weight.setText("");
        gender.setText("");
        hours.setText("");
        percent.setText("");
        fin.setText("");
        waitTime.setText("");
    }
}
