jQuery(document).ready(function($) {
    $("body").show();
    $( "#accordion" ).accordion({
        collapsible: true,
        header: '> div.accordion-section > h3',
        heightStyle: 'content'
		});
	$("#ui-accordion-accordion-header-0").delay(200).fadeIn();
	$("#ui-accordion-accordion-header-1").delay(400).fadeIn();
	$("#ui-accordion-accordion-header-2").delay(600).fadeIn();
	$("#ui-accordion-accordion-header-3").delay(800).fadeIn();
	$("#ui-accordion-accordion-header-4").delay(1000).fadeIn();
	$("#ui-accordion-accordion-header-5").delay(1200).fadeIn();
	$("#ui-accordion-accordion-header-6").delay(1400).fadeIn();
});